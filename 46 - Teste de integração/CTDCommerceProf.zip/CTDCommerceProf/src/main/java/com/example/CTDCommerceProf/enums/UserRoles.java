package com.example.CTDCommerceProf.enums;

public enum UserRoles {
    ROLE_USER, ROLE_ADMIN
}
