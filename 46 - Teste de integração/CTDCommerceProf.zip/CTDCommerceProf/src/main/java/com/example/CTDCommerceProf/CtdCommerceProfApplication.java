package com.example.CTDCommerceProf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CtdCommerceProfApplication {

	public static void main(String[] args) {

		SpringApplication.run(CtdCommerceProfApplication.class, args);
	}

}
